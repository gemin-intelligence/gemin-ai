const modes = ["Auto", "Fast", "Thinking"];
let modeIndex = 0;

const modeBtn = document.getElementById("modeBtn");
const modeLabel = document.getElementById("modeLabel");
const seeUsageBtn = document.getElementById("seeUsageBtn");
const upgradeBtn = document.getElementById("upgradeBtn");
const addBtn = document.getElementById("addBtn");
const micBtn = document.getElementById("micBtn");
const navItems = document.querySelectorAll(".nav-item");

modeBtn.addEventListener("click", () => {
  modeIndex = (modeIndex + 1) % modes.length;
  modeLabel.textContent = modes[modeIndex];
});

seeUsageBtn.addEventListener("click", () => {
  alert("Usage resets at 5:14 AM.");
});

upgradeBtn.addEventListener("click", () => {
  alert("Upgrade options are available in your account settings.");
});

addBtn.addEventListener("click", () => {
  alert("Attachment picker clicked.");
});

micBtn.addEventListener("click", () => {
  alert("Voice input clicked.");
});

navItems.forEach((item) => {
  item.addEventListener("click", () => {
    if (!item.textContent.includes("More")) {
      navItems.forEach((el) => el.classList.remove("active"));
      item.classList.add("active");
    }
  });
});